import scrapy
import requests
url = "http://172.17.50.43/freebix"
print("Status code:")
r = requests.get(url)
print("\t *",r.status_code)
#print(r.text)
h = requests.head(url)
print("Header")
print("**********")
headers= {
    'User-Agent':'Mobile'
}
url2= 'http://172.17.50.43/headers.php'
rh = requests.get(url2,headers=headers)
print(rh.text)
print("********")

class mySpider(scrapy.Spider) :
    name = 'New spider'
    start_urls = ['http://172.17.50.43/freebix']
    def parse(self,response):
        css_sel = 'img' # or xpath_sel = '//img'
        for x in response.css(css_sel) :
    #   for x in response.xpath(xpath_sell) :
            new_xpath_sel = '@src' #new_css_sel = '::attr(src)
            yield {
                'IMAGE link' : x.xpath(new_xpath_sel).extract_first()
             #   'IMAGE link' : x.css(new_css_sel).extract_first()
            }
        next_sel = '.next a::attr(href)'
        next_page = response.css(next_sel).extract_first()
        if next_page: # not last page
            yield scrapy.Request(response.urljoin(next_page),callback=self.parse)
