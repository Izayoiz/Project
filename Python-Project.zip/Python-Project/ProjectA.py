import requests
url = "http://172.17.50.43/freebix"
print("Status code:")
r = requests.get(url) #Request a "get" request
print("\t *",r.status_code)
#print(r.text)
h = requests.head(url)
print("Header")
print("**********")
headers= {
    'User-Agent':'Mobile' #Changes User-Agent to  "Mobile"
}
url2= 'http://172.17.50.43/headers.php'
rh = requests.get(url2,headers=headers)
print(rh.text)
print("**********")
