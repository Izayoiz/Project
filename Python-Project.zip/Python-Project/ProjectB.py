import scrapy
class mySpider(scrapy.Spider) :
    name = 'New spider'
    start_urls = ['http://172.17.50.43/freebix']
    def parse(self,response):
        css_sel = 'img' # or xpath_sel = '//img' This allows you to select image files
        for x in response.css(css_sel) :
    #   for x in response.xpath(xpath_sell) :
            new_xpath_sel = '@src' #new_css_sel = '::attr(src)
            yield {
                'IMAGE link' : x.xpath(new_xpath_sel).extract_first()
             #   'IMAGE link' : x.css(new_css_sel).extract_first()
            }
        next_sel = '.next a::attr(href)'
        next_page = response.css(next_sel).extract_first()
        if next_page: # Selects next page also if there is a next page
            yield scrapy.Request(response.urljoin(next_page),callback=self.parse)
